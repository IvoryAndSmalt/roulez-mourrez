<?php
//Rename this file to env.php, and place it at the root of your website/app.

$host = "localhost";
$dbname = "roulez-mourrez;charset=utf8";
$user = "phpmyadmin";
$pass = "test";

$base_url = "localhost/roulez-mourrez/";

