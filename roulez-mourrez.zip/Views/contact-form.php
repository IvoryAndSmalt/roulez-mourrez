<form method="POST" id="contactform" class="">
    <div id="forminner">
        <div id="formtitle">
            <h2 id="formh2" class="">
                <span class="">
                    Contact me
                </span>
            </h2>
        </div>
        <div id="forminputs">
            <div id="inptypetext">
                <input type="text" class="" required placeholder="Name" name="name">
                <input type="email" class="" required placeholder="Email" name="email">
		<input type="text" class="" required placeholder="Subject" name="subject">
            </div>
            <div id="message">
                <textarea name="message" required placeholder="Message" id="mymessage" class="b"></textarea>
            </div>
            <div id="submit">
                <input type="submit" value="Send" name="submit" class="">
            </div>
        </div>
    </div>
</form>